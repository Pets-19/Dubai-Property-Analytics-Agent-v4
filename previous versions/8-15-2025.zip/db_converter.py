# db_converter.py (Smarter Version)
import pandas as pd
import sqlite3
import os

CSV_FILE = "transactions-2025-08-09.csv"
DB_FILE = "properties.db"
TABLE_NAME = "properties"

def find_price_column(df_columns):
    """Intelligently finds the likely price column from a list of column names."""
    for col in df_columns:
        if 'price' in col or 'amount' in col or 'value' in col:
            return col
    return None # Return None if no likely column is found

def create_database():
    """
    Reads data from a CSV file and loads it into a new SQLite database.
    This script is safe to run multiple times.
    """
    if not os.path.exists(CSV_FILE):
        print(f"❌ ERROR: CSV file not found at '{CSV_FILE}'")
        return

    # Delete the old database file to ensure a fresh start
    if os.path.exists(DB_FILE):
        os.remove(DB_FILE)
        print(f"🗑️ Removed existing '{DB_FILE}' to rebuild it.")

    print(f"🚀 Reading data from '{CSV_FILE}'...")
    df = pd.read_csv(CSV_FILE)
    
    # Clean column names
    df.columns = df.columns.str.lower().str.replace(' ', '_')
    
    # --- INTELLIGENT DEBUGGING ---
    print("\n✅ Found the following columns in your CSV:")
    print(df.columns.tolist())
    
    price_column_name = find_price_column(df.columns)
    
    if not price_column_name:
        print("\n❌ CRITICAL ERROR: Could not automatically find a price-related column ('price', 'amount', 'value').")
        print("Please rename the price column in your CSV file and try again.")
        return
        
    print(f"\n💡 Automatically detected '{price_column_name}' as the price column.")

    conn = sqlite3.connect(DB_FILE)
    
    print(f"\n📝 Writing {len(df)} records to the '{TABLE_NAME}' table in '{DB_FILE}'...")
    df.to_sql(TABLE_NAME, conn, if_exists='replace', index=False)
    
    print(f"⚡ Creating a database index on the '{price_column_name}' column for high-speed queries...")
    cursor = conn.cursor()
    # Use the dynamically found price column name
    cursor.execute(f'CREATE INDEX "idx_{price_column_name}" ON "{TABLE_NAME}" ("{price_column_name}");')
    
    conn.commit()
    conn.close()

    print(f"\n✅ Successfully created and populated '{DB_FILE}'. You can now run the main app.")

if __name__ == "__main__":
    create_database()