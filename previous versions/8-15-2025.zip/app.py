# app.py (Final, Definitive Version - All Filters Confirmed)
import os
import sqlite3
from flask import Flask, jsonify, render_template, request
import time
import json
import re

# --- Configuration ---
DB_FILE = "properties.db"

# --- Helper functions ---
def get_db_columns(db_path):
    if not os.path.exists(db_path): return []
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.execute("PRAGMA table_info(properties);")
        columns = [row[1] for row in cursor.fetchall()]
        conn.close()
        return columns
    except Exception as e:
        print(f"Error reading database columns: {e}")
        return []

def find_column_name(all_columns, potential_matches):
    for match in potential_matches:
        if match in all_columns:
            return match
    return potential_matches[0]

# --- Dynamic Column Mapping ---
ALL_DB_COLUMNS = get_db_columns(DB_FILE)
COLUMN_MAP = {
    'price': find_column_name(ALL_DB_COLUMNS, ['trans_value', 'price']),
    'property_type': find_column_name(ALL_DB_COLUMNS, ['prop_type_en', 'property_type']),
    'bedrooms': find_column_name(ALL_DB_COLUMNS, ['rooms_en', 'bedrooms']),
    'status': find_column_name(ALL_DB_COLUMNS, ['is_offplan_en', 'development_status']),
    'location': find_column_name(ALL_DB_COLUMNS, ['project_en', 'location', 'nearest_landmark_en']),
    'name': find_column_name(ALL_DB_COLUMNS, ['procedure_en', 'property_name'])
}

# --- Initialize Flask App ---
app = Flask(__name__, template_folder='templates', static_folder='static')

def get_db_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

# --- Core Filtering Logic (DEFINITIVE VERSION) ---
def find_properties(max_budget, prop_type, bedrooms, status):
    conditions = []
    params = {}

    conditions.append(f"`{COLUMN_MAP['price']}` <= :budget")
    params['budget'] = int(max_budget)

    if prop_type and 'all' not in prop_type.lower():
        if 'apartment' in prop_type.lower():
            conditions.append(f"`{COLUMN_MAP['property_type']}` = 'Unit'")
        elif 'building' in prop_type.lower():
            conditions.append(f"`{COLUMN_MAP['property_type']}` = 'Building'")
        elif 'land' in prop_type.lower():
            conditions.append(f"`{COLUMN_MAP['property_type']}` = 'Land'")

    # --- FINAL, SIMPLIFIED BEDROOM LOGIC ---
    if bedrooms and 'any' not in bedrooms.lower():
        beds_col = f"`{COLUMN_MAP['bedrooms']}`"
        if 'studio' in bedrooms.lower():
            conditions.append(f"{beds_col} = 'Studio'")
        else:
            try:
                # Extracts the number (e.g., '1' from '1 Bedroom')
                num_beds_str = re.findall(r'\d+', bedrooms)[0]
                # Simple text search: finds rows that start with the number (e.g., '1 B/R')
                conditions.append(f"{beds_col} LIKE :bedrooms_like")
                params['bedrooms_like'] = f"{num_beds_str} %"
            except (ValueError, IndexError):
                 pass # Ignore invalid formats

    if status and 'any' not in status.lower():
        status_col = f"`{COLUMN_MAP['status']}`"
        if 'ready' in status.lower():
            conditions.append(f"{status_col} = 'Ready'")
        elif 'off-plan' in status.lower():
            conditions.append(f"{status_col} = 'Off-Plan'")

    query = f"SELECT * FROM properties WHERE {' AND '.join(conditions)};"
    
    print(f"\n--- Final Executed Query ---\nQuery: {query}\nParams: {params}\n--------------------------\n")

    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(query, params)
        results = [dict(row) for row in cursor.fetchall()]
    except Exception as e:
        print(f"❌ DATABASE EXECUTION FAILED: {e}")
        results = []
    finally:
        conn.close()
        
    return results

# --- Web Routes ---
@app.route('/')
def home():
    if not os.path.exists(DB_FILE):
        return "<h1>Error: Database file not found. Please run `db_converter.py`</h1>", 500
    return render_template('index.html', column_map=COLUMN_MAP)

@app.route('/search', methods=['POST'])
def search():
    start_time = time.time()
    data = request.json
    results = find_properties(
        data.get('budget', 999999999), data.get('propertyType'),
        data.get('bedrooms'), data.get('status')
    )
    end_time = time.time()
    print(f"🚀 Query took: {end_time - start_time:.4f}s. Found {len(results)} results.")
    return jsonify(results)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)